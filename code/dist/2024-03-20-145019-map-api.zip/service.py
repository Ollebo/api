# -*- coding: utf-8 -*-
import time
import time
import json
from maps import maps

def mapsRoute(payload,request):
	#payload = request.get_json(silent=True)
	return maps(payload,request)

def handler(event, context):
    # Your code goes here!
    request = {
          "method": event["httpMethod"]
    }
    payload = event["body"]
    print(request)
    print(payload)
    return mapsRoute(payload,request)